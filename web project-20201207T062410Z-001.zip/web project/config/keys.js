module.exports = {
  mongoURI: "mongodb+srv://Vijitkchary:Mongodb%402001@socialnetwork.ywhyn.mongodb.net/social?retryWrites=true&w=majority",
  secretOrKey: "secret"
};
