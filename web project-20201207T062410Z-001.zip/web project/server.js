var express =require("express");
var app = express();
var mongoose = require("mongoose");
var bodyParser = require("body-parser");
var path = require("path");
var passport = require("passport");
const users = require("./routes/api/users");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const keys = require("./config/keys");

// mongoose.connect("mongodb+srv://Vijitkchary:Mongodb%402001@socialnetwork.ywhyn.mongodb.net/social?retryWrites=true&w=majority",{useNewUrlParser: true, useUnifiedTopology: true}, function(err){
//     if(err){
//         console.log(err)
//     }
//     else{
//         console.log("MongoDB Connected");
//     }
// });


// DB Config
const db = require("./config/keys").mongoURI;

// Connect to MongoDB
mongoose
  .connect(
    db,
    { useNewUrlParser: true,useUnifiedTopology: true}
  )
  .then(() => console.log("MongoDB successfully connected"))
  .catch(err => console.log(err));

// Passport middleware
app.use(passport.initialize());

// Passport config
require("./config/passport")(passport);

// Bodyparser middleware
app.use(
    bodyParser.urlencoded({
      extended: false
    })
  );
app.use(bodyParser.json());

app.use(express.static(path.join(__dirname + '/public')));

var engines = require('consolidate');

app.set('views', __dirname + '/views');
app.engine('html', engines.mustache);
app.set('view engine', 'html');


// Load input validation
const validateRegisterInput = require("./validation/register");
const validateLoginInput = require("./validation/login");

// Load User model
const User = require("./models/User");

// @route POST api/users/register
// @desc Register user
// @access Public

app.get("/register",function(req,res){
  res.render("signup")
})

app.post("/register", (req, res) => {
  // Form validation

//   const { errors, isValid } = validateRegisterInput(req.body);

//   // Check validation
//   if (!isValid) {
//     return res.status(400).json(errors);
//   }

  User.findOne({ email: req.body.email }).then(user => {
    if (user) {
      return res.status(400).json({ email: "Email already exists" });
    } else {
      const newUser = new User({
        // name: req.body.name,
        email: req.body.email,
        password: req.body.password
      });

      // Hash password before saving in database
      bcrypt.genSalt(10, (err, salt) => {
        bcrypt.hash(newUser.password, salt, (err, hash) => {
          if (err) throw err;
          newUser.password = hash;
          newUser
            .save()
            .catch(err => console.log(err));
            res.redirect("/login");
        });
      });
    }
  });
});

// @route POST api/users/login
// @desc Login user and return JWT token
// @access Public

app.get("/login",function(req,res){
    res.render("Loginpage");
})

app.post("/login", (req, res) => {
  // Form validation

//   const { errors, isValid } = validateLoginInput(req.body);

//   // Check validation
//   if (!isValid) {
//     return res.status(400).json(errors);
//   }

  const email = req.body.email;
  const password = req.body.password;

  // Find user by email
  User.findOne({ email }).then(user => {
    // Check if user exists
    if (!user) {
      return res.status(404).json({ emailnotfound: "Email not found" });
    }

    // Check password
    bcrypt.compare(password, user.password).then(isMatch => {
      if (isMatch) {
        // User matched
        // Create JWT Payload
        const payload = {
          id: user.id,
          email: user.email
        };

        // Sign token
        jwt.sign(
          payload,
          keys.secretOrKey,
          {
            expiresIn: 31556926 // 1 year in seconds
          },
          (err, token) => {
            res.json({
              success: true,
              token: "Bearer " + token
            });
          }
        );
        res.redirect("/socialnetwork");
      } else {
        return res
          .status(400)
          .json({ passwordincorrect: "Password incorrect" });
      }
    });
  });
});




app.get("/socialnetwork",function(req,res){
    res.render("SocialNetwork");
})

app.get("/feeds",function(req,res){
    res.render("Feeds");
})

app.get("/notifications",function(req,res){
    res.render("Notifications");
})

app.get("/resources",function(req,res){
    res.render("Resources");
})
app.get("/chats",function(req,res){
    res.render("chats");
})

app.get("*",function(req,res){
    res.send("The Page You are looking for doesn't exist");
})

app.listen(3000,function(err){
    if(err){
        console.log(err);
    }
    else{
        console.log("Server has started");
    }
})